#include <16f877a.h>
#fuses HS,NOWDT,NOPROTECT,NOPUT,NOLVP,BROWNOUT
#use delay(clock=4M)
#use standard_io(a,b,c,e)
#define LCD_ENABLE_PIN PIN_D1
#define LCD_RS_PIN PIN_C3
#define LCD_RW_PIN PIN_D0
#define LCD_DATA4 PIN_D4
#define LCD_DATA4 PIN_D2
#define LCD_DATA4 PIN_D3
#define LCD_DATA4 PIN_C4
#include <lcd.c>

void main(void)
{
lcd_init();
lcd_gotoxy(1,1);
printf(LCD_PUTC,"sensor");

   while(true)
   {
   
      output_high(PIN_E0);
      output_high(PIN_E1);
      output_high(PIN_E2);
   }
}
