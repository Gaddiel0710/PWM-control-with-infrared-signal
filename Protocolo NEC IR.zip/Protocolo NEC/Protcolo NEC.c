#include <16f877a.h>
#fuses HS,NOWDT,NOPROTECT,NOPUT,NOLVP,BROWNOUT
#use delay(clock=20M)
#use i2c(Master,Fast=100000, sda=PIN_C4, scl=PIN_C3,force_sw)  // librer�� para manejar la comunicaci�n I2C
#include "i2c_Flex_LCD.c" //driver para manejar la interface LCD I2C
#include <NEC_ir.c>                                      // Libreria para el uso del protocolo NEC

void main()
{
   lcd_init(0x4E,16,2); //inicializacion de la lcd
   lcd_backlight_led(ON); //encendido de la luz de fondo  
   nec_ir_init();                                        // Inicializa el protocolo NEC  
   lcd_gotoxy(1,1);
   lcd_putc("Address: 0x0000");
   lcd_gotoxy(1,2);
   lcd_putc("Code: 0x0000");
   
   while(true)
   {
      if(nec_data_read == 1)                             // Verifica si ha recibido datos
      {
         nec_data_read = 0;
         nec_get_data();                                 // Obtiene los 32 bits
         unsigned long address = read_ir_address();      // Lee la direccion
         unsigned long ir_code = read_ir_code();         // Lee el comando
         
         lcd_clear();
         lcd_gotoxy(1,1);
         printf(lcd_putc,"Address: 0x%LX",address);      // Imprime la direccion
         lcd_gotoxy(1,2);
         printf(lcd_putc,"Code: 0x%LX", ir_code);        // Imprime el comando
      }
   }
}
